# include "iGraphics.h"
#include <iostream>
#include <cstdlib>
#include<vector>
#include<algorithm>
#include<windows.h>
#include<MMsystem.h>
#pragma comment(lib,"winmm.lib")
#define pb push_back
#define ll unsigned long long int
#define pb push_back
#define FR2SQ(f,r) (21+f)+(r*10)
using namespace std;
char str[100], str2[100],cntt=-1;
int hmm=0,fstx=10,fsty=680,ax=123,ay=663;
int x=98,y,len,brd_sq_num=120,cur_piece,cur_state1,cur_state2,total_move,mov_piece[32],white_ki_chk=0,black_ki_chk=0,white_ki_pos,black_ki_pos;
int knDir[8]={-8,-19,-21,-12,8,19,21,12},exi=0;
int rkDir[4]={-1,-10,1,10};
int biDir[4]={-9,-11,11,9};
int quDir[8]={-1,-10,1,10,-9,-11,11,9};
int kiDir[8]={-11,-10,-9,-1,1,9,10,11};
int piece[32];
int pieceknight[13],pieceki[13],piecerqu[13],piecebq[13];
#define pop(b) PopBit(b)
#define count countBit(b)
int w_b=1,w_k=2,w_q=3,w_ki=4,w_p=5;
struct S_board{
    int pieces[120],pList[13][10];
    ll pawns[3],pos_ke,py;
    int king_square[2],side,ply,fifty_move,his_ply,piece_num[13],bigPce[3],majPce[3],minPce[3];
};
struct stat_to_co{
    int x_co,y_co;
}
stat_to_co[120];
int sq120to64[120],sq64to120[64];
extern int sq120to64[120],sq64to120[64];
int col[64];
int mode,y1=152,x1=108;

enum {File_A,File_B,File_C,File_D,File_E,File_F,File_G,File_H};
enum {Empty,w_pa,w_kn,w_bi,w_ro,w_qu,w_kin,b_pa,b_kn,b_bi,b_ro,b_qu,b_kin};
enum {rank_1,rank_2,rank_3,rank_4,rank_5,rank_6,rank_7,rank_8};
enum {White,Black,Both};
enum {A1=21,B1,C1,D1,E1,F1,G1,H1,
      A2=31,B2,C2,D2,E2,F2,G2,H2,
      A3=41,B3,C3,D3,E3,F3,G3,H3,
      A4=51,B4,C4,D4,E4,F4,G4,H4,
      A5=61,B5,C5,D5,E5,F5,G5,H5,
      A6=71,B6,C6,D6,E6,F6,G6,H6,
      A7=81,B7,C7,D7,E7,F7,G7,H7,
      A8=91,B8,C8,D8,E8,F8,G8,H8,No_sq
};
int box[64];
char im[10][20]={"images\\1.bmp","images\\2.bmp","images\\3.bmp"};
char bl[15][20]={"images\\b_b.bmp","images\\b_k.bmp","images\\b_ki.bmp","images\\b_p.bmp","images\\b_q.bmp","images\\b_r.bmp"};
char wh[15][20]={"images\\w_b.bmp","images\\w_k.bmp","images\\w_ki.bmp","images\\w_p.bmp","images\\w_q.bmp","images\\w_r.bmp"};
char win[10][30]={"images\\white_win.bmp","images\\Black_win.bmp","images\\white.bmp","images\\black.bmp"};
int st = -1,a,b,state;
int pos[120];
int timer[10];
struct clock {
    int time_left;
    char minute[5];
    char strSecond[6];
} blackClock, whiteClock;
vector<string> moves;
char* itoa2(int num,char str[])
{
    vector<char>v;
    int len=0,num1=num;

    while(num)
    {

        len++,v.pb(num%10+'0'),num/=10;
    }
    reverse(v.begin(),v.end());
    //cout<<num1<< " "<<len<<"\n";
    for(int i=0;i<len;i++)str[i]=v[i];
    str[len]='\0';
    return str;
}
void showClock()
{
    iSetColor(130,135,255);
    itoa2(whiteClock.time_left, whiteClock.strSecond);
    itoa2(blackClock.time_left, blackClock.strSecond);
    iText(350,110,whiteClock.strSecond, GLUT_BITMAP_TIMES_ROMAN_24);
    iText(350, 680, blackClock.strSecond, GLUT_BITMAP_TIMES_ROMAN_24);
}
void init_Clock()
{
    blackClock.time_left = 300;
    whiteClock.time_left = 300;
}
void updateClock_black()
{
    if(blackClock.time_left>=01)
    blackClock.time_left--;
}

void updateClock_white()
{
    if(whiteClock.time_left>=01)
    whiteClock.time_left--;
}
void drawBoard()
{
	iSetColor(150, 150, 150);

	int width=64;
	for(int i=0;i<8;i++)
    {
        for(int j=0;j<8;j++)
        {
            if((i+j)%2==0)
            {
                iSetColor(0,0,139);
            }
            else iSetColor(173,216,230);
            iFilledRectangle(98+width*i,142+width*j,width,width);
        }
    }

}
const int bitTable[64]={63,30,3,32,25,41,22,33,15,50,42,13,11,53,19,34,61,29,2,51,21,43,45,10,18,47,1,54,9,57,0,
35,62,31,40,4,49,5,52,26,60,6,23,44,46,27,56,16,7,39,48,24,59,14,12,55,38,28,58,
20,37,17,36,8
};
int PopBit(ll *bb)
{
    ll  b=*bb ^(*bb-1);
    unsigned int fold=(unsigned) ((b& 0xffffffff)^(b<<32));
    *bb &=(*bb-1);
    return bitTable[(fold * 0x783a9b23)>>26];
}
ll countBit(ll b)
{
    int r;
    for(r=0;b;b&=(b-1))r++;
    return r;
}
void move_piece()
{

}

void initsq120to64()
{
    int index=0,file=File_A,rank1=rank_1,sq=A1,sq64=0;
    for(;index<brd_sq_num;index++)
    {
        sq120to64[index]=65;
    }
    for(index=0;index<64;index++)sq64to120[index]=120;
    for(rank1=rank_1;rank1<=rank_8;rank1++)
    {
        for(file=File_A;file<=File_H;file++)
        {
            sq=(FR2SQ(file,rank1));
            sq64to120[sq64]=sq;
            sq120to64[sq]=sq64,sq64++;
        }
    }
}
/*
	function iDraw() is called again and again by the system.
*/
int valid_knight(int state1,int state2,int col)
{
    for(int i=0;i<8;i++)
    {
        int newstate=state1+knDir[i];
        if(newstate==state2)
        {
            if(box[sq120to64[state2]]!=32)
            {
                if((box[sq120to64[state2]]<16)^col==1)return 1;
            }
            else return 1;
        }
    }
    return 0;
}
int valid_b(int state1,int state2,int col)
{
    int i=0,newstate;
    while(i<4)
    {
        newstate=state1;
        int bx=sq120to64[newstate];
        while(bx>=0 && bx<=63)
        {
            newstate+=biDir[i],bx=sq120to64[newstate];
            //cout<<newstate<<" "<<state2<<" "<<bx<<" "<<box[bx]<<"\n";
            if(bx<=63 && box[bx]!=32)
            {
                if(((box[bx]<16)^ col)==0 && box[bx]!=cur_piece)break;
                else{
                    if(newstate==state2)return 1;
                    else break;
                }
            }
            else if(newstate==state2)return 1;
        }
        i++;
    }
    return 0;
}
int valid_ki(int state1,int state2,int col)
{
    int i=0,newstate;
    while(i<8)
    {
        newstate=state1;
        int bx;
        newstate+=kiDir[i],bx=sq120to64[newstate];
        if(bx>=0 && bx<=63)
        {
            //if(state1==25)cout<<"king "<<state1<<" "<<newstate<<" "<<col<<" "<<bx<<"\n";
            if(box[bx]!=32)
            {
                if(((box[bx]<16)^ col)==0){
                    i++;
                    continue;
                }
                else{
                    if(newstate==state2){
                        return 1;
                    }else {
                        i++;
                        continue;
                    }
                }
            }
            else if( newstate==state2){
                return 1;
            }
        }
        i++;
    }
    return 0;
}
int valid_r(int state1,int state2,int col)
{
    int i=0,newstate;
    while(i<4)
    {
        newstate=state1;
        int bx=sq120to64[newstate];
        while(bx>=0 && bx<=63)
        {
            newstate+=rkDir[i],bx=sq120to64[newstate];
            //cout<<newstate<<" "<<state2<<" "<<bx<<" "<<box[bx]<<"\n";
            if(bx<=63 && box[bx]!=32)
            {
                if(((box[bx]<16)^ col)==0 && box[bx]!=cur_piece)break;
                else{
                    if(newstate==state2)return 1;
                    else break;
                }
            }
            else if(newstate==state2)return 1;
        }
        i++;
    }
    return 0;
}
int valid_qu(int state1,int state2,int col)
{
    int i=0,newstate;
    while(i<8)
    {
        newstate=state1;
        int bx=sq120to64[newstate];
        while(bx>=0 && bx<=63)
        {
            newstate+=quDir[i],bx=sq120to64[newstate];

            if(bx<=63 && box[bx]!=32)
            {
                if(((box[bx]<16)^ col)==0 && box[bx]!=cur_piece)break;
                else{
                    if(newstate==state2)return 1;
                    else break;
                }
            }
            else if(newstate==state2)return 1;
        }
        i++;
    }
    return 0;
}
int valid_pa(int state1,int state2,int col)
{
    int newstate;
    if(col==01)
    {
        newstate=state1;
        int bx=sq120to64[newstate],bx2=sq120to64[state2];
        //cout<<state2<<" "<<state1<<" "<<cur_piece<<" "<<mov_piece[cur_piece]<<" "<<box[bx2]<<"\n";
        if(state2==state1+10)
        {
            if(box[bx2]==32)
                return 1;
        }
        else if(state2==state1+20)
        {
            if(mov_piece[cur_piece]==0 && box[bx2]==32 && box[sq120to64[state1+10]]==32)
                return 1;
        }
        else if(state2==state1+11 || state2==state1+9)
        {
            if(15<=box[bx2] && box[bx2]<=31)
                return 1;
        }
    }
    else
    {
        newstate=state1;
        int bx=sq120to64[newstate],bx2=sq120to64[state2];
        //cout<<state2<<" "<<state1<<" "<<cur_piece<<" "<<mov_piece[cur_piece]<<" "<<box[bx2]<<"\n";

        if(state2==state1-10)
        {
            if(box[bx2]==32)
            {
                return 1;
            }
        }
        else if(state2==state1-20)
        {
            if(mov_piece[cur_piece]==0 && box[bx2]==32 && box[sq120to64[state1-10]]==32){

                return 1;
            }
        }
        else if(state2==state1-11 || state2==state1-9)
        {
            if(0<=box[bx2] && box[bx2]<=15){
                return 1;
            }
        }
    }
    return 0;
}
int attack_pa(int state1,int state2,int col)
{
    int newstate;
    if(col==01)
    {
        newstate=state1;
        int bx=sq120to64[newstate],bx2=sq120to64[state2];
        //cout<<state2<<" "<<state1<<" "<<cur_piece<<" "<<mov_piece[cur_piece]<<" "<<box[bx2]<<"\n";
        if(state2==state1+11 || state2==state1+9)
        {
            if(15<=box[bx2] && box[bx2]<=31)
                return 1;
        }
    }
    else
    {
        newstate=state1;
        int bx=sq120to64[newstate],bx2=sq120to64[state2];
        //cout<<state2<<" "<<state1<<" "<<cur_piece<<" "<<mov_piece[cur_piece]<<" "<<box[bx2]<<"\n";
        if(state2==state1-11 || state2==state1-9)
        {
            if(0<=box[bx2] && box[bx2]<=15){
                return 1;
            }
        }
    }
    return 0;
}
int chk(int state2,int col)
{
    for(int i=0;i<=63;i++)
    {
        int state1=sq64to120[i],st1=sq120to64[state1];
        if(state1!=state2)
        {
            if(col==1)
            {
                if((0<=box[st1] && box[st1]<=15)==0 && box[st1]!=32)
                {
                    if(piece[box[st1]]==6)
                    {
                        if(valid_b(state1,state2,col^1))return 0;
                    }
                    else if(piece[box[st1]]==7)
                    {
                        if(valid_knight(state1,state2,col^1))return 0;
                    }
                    else if(piece[box[st1]]==8)
                    {
                        if(valid_ki(state1,state2,col^1))return 0;
                    }
                    else if(piece[box[st1]]==9)
                    {
                        if(attack_pa(state1,state2,col^1))return 0;
                    }
                    else if(piece[box[st1]]==10)
                    {
                        if(valid_qu(state1,state2,col^1))return 0;
                    }
                    else if(piece[box[st1]]==11){
                        if(valid_r(state1,state2,col^1)){
                            return 0;
                        }
                    }
                }
            }
            else{
                if((0<=box[st1] && box[st1]<=15)==1 && box[st1]!=32)
                {
                    if(piece[box[st1]]==0)
                    {
                        if(valid_b(state1,state2,col^1))return 0;
                    }
                    else if(piece[box[st1]]==1)
                    {
                        if(valid_knight(state1,state2,col^1))return 0;
                    }
                    else if(piece[box[st1]]==2)
                    {
                        if(valid_ki(state1,state2,col^1))return 0;
                    }
                    else if(piece[box[st1]]==3)
                    {
                        if(attack_pa(state1,state2,col^1))return 0;
                    }
                    else if(piece[box[st1]]==4)
                    {
                        if(valid_qu(state1,state2,col^1)){

                            return 0;
                        }
                    }
                    else if(piece[box[st1]]==5){
                        if(valid_r(state1,state2,col^1))return 0;
                    }
                }
            }
        }
    }
    return 01;
}
void showab()
{
    iSetColor(188,99,222);
    int q=64;
    int ax=123,ay=663;
    //cout<<"ax "<<ax<<"\n";
    iText(ax,ay,"a",GLUT_BITMAP_TIMES_ROMAN_24);
    iText(ax+q,ay,"b",GLUT_BITMAP_TIMES_ROMAN_24);
    iText(ax+2*q,ay,"c",GLUT_BITMAP_TIMES_ROMAN_24);
    iText(ax+3*q,ay,"d",GLUT_BITMAP_TIMES_ROMAN_24);
    iText(ax+ 4*q,ay,"e",GLUT_BITMAP_TIMES_ROMAN_24);
    iText(ax+5*q,ay,"f",GLUT_BITMAP_TIMES_ROMAN_24);
    iText(ax+6*q,ay,"g",GLUT_BITMAP_TIMES_ROMAN_24);
    iText(ax+7*q,ay,"h",GLUT_BITMAP_TIMES_ROMAN_24);
    ax=620,ay=634;
    iSetColor(152,252,52);
    iText(ax,ay,"1",GLUT_BITMAP_TIMES_ROMAN_24);
    iText(ax,ay-q,"2",GLUT_BITMAP_TIMES_ROMAN_24);
    iText(ax,ay-2*q,"3",GLUT_BITMAP_TIMES_ROMAN_24);
    iText(ax+0,ay-3*q,"4",GLUT_BITMAP_TIMES_ROMAN_24);
    iText(ax+ 0,ay-4*q,"5",GLUT_BITMAP_TIMES_ROMAN_24);
    iText(ax+0,ay-5*q,"6",GLUT_BITMAP_TIMES_ROMAN_24);
    iText(ax+0,ay-6*q,"7",GLUT_BITMAP_TIMES_ROMAN_24);
    iText(ax+0,ay-7*q,"8",GLUT_BITMAP_TIMES_ROMAN_24);

}

void iDraw()
{
	//place your drawing codes here

	iClear();
	//iShowBMP(50,100,im[1]);
	if(st==-1)
    {
        iSetColor(255,255,255);
        iFilledRectangle(100,100,650,650);
        iSetColor(255,67,133);
        iText(125,502,"CSE 102 Project:", GLUT_BITMAP_TIMES_ROMAN_24);
        iText(125,472,"Chess Game", GLUT_BITMAP_TIMES_ROMAN_24);
        iSetColor(0,0,0);
        iText(125,402,"Instructor: Fatima Nawmi", GLUT_BITMAP_TIMES_ROMAN_24);
        iText(125,372,"Lecturer", GLUT_BITMAP_TIMES_ROMAN_24);
        iText(125,342,"Department of CSE, BUET", GLUT_BITMAP_TIMES_ROMAN_24);
        iShowBMP(400,250,"images\\NawmiMam.bmp");
    }
    else if(st==-2)
    {
        //;drawTextBox();
    }
	else if(st==0) {
        iShowBMP(30,300,im[01]);
	}

    else  if(st==1) {
        //iShowBMP(40,10,im[0]);
        showClock();
        drawBoard();
        showab();
        iShowBMP2(x1+64*2,y1,bl[0],255);
        iShowBMP2(x1+64*5,y1,bl[0],255);
        iShowBMP2(x1+64*1,y1,bl[1],255);
        iShowBMP2(x1+64*6,y1,bl[1],255);
        iShowBMP2(x1+64*4,y1,bl[2],255);
        iShowBMP2(x1+64*3,y1,bl[4],255);
        iShowBMP2(x1+64*0,y1,bl[5],255);
        iShowBMP2(x1+64*7,y1,bl[5],255);

        iShowBMP2(x1+64*2,y1+64*7,wh[0],255);
        iShowBMP2(x1+64*5,y1+64*7,wh[0],255);
        iShowBMP2(x1+64*1,y1+64*7,wh[1],255);
        iShowBMP2(x1+64*6,y1+64*7,wh[1],255);
        iShowBMP2(x1+64*4,y1+64*7,wh[2],255);
        iShowBMP2(x1+64*3,y1+64*7,wh[4],255);
        iShowBMP2(x1+64*0,y1+64*7,wh[5],255);
        iShowBMP2(x1+64*7,y1+64*7,wh[5],255);
        for(int i=0;i<8;i++)
        {
            iShowBMP2(108+i*64,y1+64,bl[3],255);
        }
        for(int i=0;i<8;i++)
        {
            iShowBMP2(108+i*64,y1+64*6,wh[3],255);
        }
	}
	else{
        showab();
        if(st==2)
        {
            drawBoard();
            showClock();
            for(int i=63;i>=0;i--)
            {
                int k=piece[box[i]],x2=stat_to_co[sq64to120[i]].x_co,y2=stat_to_co[sq64to120[i]].y_co;

                if(box[i]!=32)
                {
                    if(k<6)iShowBMP2(x2,y2,wh[k],255);
                    else iShowBMP2(x2,y2,bl[k-6],255);
                    //iSetColor(150,150,200);
                    //if(col[i]!=-1)iFilledCircle(x2+10,y2+10,4);
                }
                //iSetColor(100,100,100);
                //if(col[i]!=-1)iFilledCircle(x2+14,y2+10,4);
            }
        }
        else{
            drawBoard();
            showClock();
            for(int i=63;i>=0;i--)
            {
                int k=piece[box[i]],x2=stat_to_co[sq64to120[i]].x_co,y2=stat_to_co[sq64to120[i]].y_co;

                if(box[i]!=32)
                {
                    if(k<6)iShowBMP2(x2,y2,wh[k],255);
                    else   iShowBMP2(x2,y2,bl[k-6],255);
                }
                iSetColor(150,120,200);
                if(col[i]!=-1){
                    if(box[i]==32){
                       iFilledCircle(x2+20,y2+20,7);
                    }
                    else {
                        iSetColor(253,1,1);
                        iFilledCircle(x2+20,y2+20,7);
                    }
                }
            }
        }
        int si=moves.size();
        int fstx=10,fsty=680,ct=0;
        for(int i1=max(0,si-20);i1<si;i1++)
        {

            char  p[1000];
            int stt=0;
            for(int j=0;moves[i1][j];j++)
            {
                p[stt]=moves[i1][stt],stt++;
            }
            p[stt]='\0';
            if(!(p[0]=='W' || p[0]=='B' || p[0]=='c'))
            {
                if(ct%2==0)iSetColor(255,255,209);
                else iSetColor(110,170,233);
                ct++;
            }
            else iSetColor(77,88,242);
            iText(fstx,fsty,p,GLUT_BITMAP_9_BY_15),fsty-=25;
        }
	}
	if(st>=1 && exi==0)
        iText(50,65,"Resign!", GLUT_BITMAP_TIMES_ROMAN_24);
    if(st==0 && cntt==-1)
    {
        init_Clock(),cntt=0;
        timer[0] = iSetTimer(1000, updateClock_black);
        //iPauseTimer(timer[0]);
        timer[1] = iSetTimer(1000, updateClock_white);
    }
	if(total_move>=1 && whiteClock.time_left==0)
    {
        iShowBMP(100,300,win[0]);
        //exit(0);
    }
    if(total_move>=1 && blackClock.time_left==0)
    {
        iShowBMP(100,300,win[1]);
        //exit(0);
    }
    if(exi==01)
    {
        for(int i=1;i<=500000000;i++);
        iShowBMP(100,300,win[3]);
        iPauseTimer(timer[0]);
        iPauseTimer(timer[01]);
    }
    else if(exi==2)
    {
        for(int i=1;i<=500000000;i++);
        iShowBMP(0,300,win[2]);
        iPauseTimer(timer[0]);
        iPauseTimer(timer[01]);
    }
	else if(total_move%2==1){
        iPauseTimer(timer[0]);
        iResumeTimer(timer[1]);
	}
	else if(total_move%2==0){
        iPauseTimer(timer[01]);
        iResumeTimer(timer[0]);
	}
}

/*
	function iMouseMove() is called when the user presses and drags the mouse.
	(mx, my) is the position where the mouse pointer is.
*/
void iMouseMove(int mx, int my)
{
	//place your codes here

	//printf("%d %d\n",mx,my);
}

/*
	function iMouse() is called when the user presses/releases the mouse.
	(mx, my) is the position where the mouse pointer is.
*/
int stat(int mx,int my)
{
    int cnt=0,cnt2=1;
	for(int i=98;i<=mx;i+=64)
    {
        cnt++;
    }
    for(int j=654;j>=my;j-=64)
    {
        cnt2++;
    }
    state=cnt2*10+cnt;
}
void pus(int piec,int bx1,int bx2)
{
    string s;
    if(piec==0 || piec==6)s="bi ";
    else if(piec==1 || piec==7)s="kn ";
    else if(piec==2 || piec==8)s="ki ";
    else if(piec==3 || piec==9)s="pa ";
    else if(piec==4 || piec==10)s="qu ";
    else s="ro ";
    if(bx1%8==0)s+="a";
    else if(bx1%8==1)s+="b";
    else if(bx1%8==2)s+="c";
    else if(bx1%8==3)s+="d";
    else if(bx1%8==4)s+="e";
    else if(bx1%8==5)s+="f";
    else if(bx1%8==6)s+="g";
    else if(bx1%8==7)s+="h";
    if(bx1/8==0)s+="1";
    else if(bx1/8==1)s+="2";
    else if(bx1/8==2)s+="3";
    else if(bx1/8==3)s+="4";
    else if(bx1/8==4)s+="5";
    else if(bx1/8==5)s+="6";
    else if(bx1/8==6)s+="7";
    else if(bx1/8==7)s+="8";

    if(bx2%8==0)s+="a";
    else if(bx2%8==1)s+="b";
    else if(bx2%8==2)s+="c";
    else if(bx2%8==3)s+="d";
    else if(bx2%8==4)s+="e";
    else if(bx2%8==5)s+="f";
    else if(bx2%8==6)s+="g";
    else if(bx2%8==7)s+="h";
    if(bx2/8==0)s+="1";
    else if(bx2/8==1)s+="2";
    else if(bx2/8==2)s+="3";
    else if(bx2/8==3)s+="4";
    else if(bx2/8==4)s+="5";
    else if(bx2/8==5)s+="6";
    else if(bx2/8==6)s+="7";
    else if(bx2/8==7)s+="8";
    moves.pb(s);
}
void iMouse(int button, int state, int mx, int my)
{
    cout<<mx<<" "<<my<<" "<<st<<"\n";
    if(st!=0)
    {
        if(exi==0 && mx>=50 && my>=65 && mx<=130 && my<=87)
        {
            if(total_move%2==0){
                exi=1;
            }
            else exi=2;
        }
    }
    if(st==-1 && button == GLUT_LEFT_BUTTON  && state==GLUT_DOWN)
	{

        if(mx>=0 && my>=0 && my<=600 && mx<=600)
        {
            st=-2;
        }
        //cout<<cnt<<"\n";
		//place your codes here
	}
	else if(st==-2 && button==GLUT_LEFT && state==GLUT_DOWN )
    {
        st=0;
    }
	else if(st==0 && button == GLUT_LEFT &&state==GLUT_DOWN )
	{
        if(mx>=0 && my>=0 && my<=700 && mx<=700)
        {
            st=1;
        }
        //cout<<cnt<<"\n";
		//place your codes here
	}
	else{
        if(st==1 && button==GLUT_LEFT_BUTTON)
        {
            st=2;
        }
        else if(st==2 && button==GLUT_LEFT_BUTTON && state==GLUT_DOWN)
        {
            int cur_state=sq120to64[stat(mx,my)];
            cur_piece=box[cur_state];
            cur_state1=stat(mx,my);
            if(total_move%2==0 )
            {
                if(piece[cur_piece]==1)
                {
                    for(int i=0;i<64;i++)
                    {
                        if(valid_knight(cur_state1,sq64to120[i],1)){
                            swap(box[i],box[cur_state]);
                            if(chk(sq64to120[white_ki_pos],1)==1)col[i]=1;
                            swap(box[i],box[cur_state]);
                        }
                        else col[i]=-1;
                    }
                }
                else if(piece[cur_piece]==0)
                {
                    for(int i=0;i<64;i++)
                    {
                        if(valid_b(cur_state1,sq64to120[i],01)){
                            swap(box[i],box[cur_state]);
                            if(chk(sq64to120[white_ki_pos],1)==1)col[i]=1;
                            swap(box[i],box[cur_state]);
                        }
                        else col[i]=-1;
                    }
                }
                else if(piece[cur_piece]==5)
                {
                    for(int i=0;i<64;i++)
                    {
                        if(valid_r(cur_state1,sq64to120[i],1)){
                            swap(box[i],box[cur_state]);
                            if(chk(sq64to120[white_ki_pos],1)==1)col[i]=1;
                            swap(box[i],box[cur_state]);
                        }
                        else col[i]=-1;
                    }
                }
                else if(piece[cur_piece]==4)
                {
                    for(int i=0;i<64;i++)
                    {
                        if(valid_qu(cur_state1,sq64to120[i],1)){
                            swap(box[i],box[cur_state]);
                            cout<<i<<" "<<box[i]<<" "<<box[cur_state]<<"cur state\n";
                            if(chk(sq64to120[white_ki_pos],1)==1)col[i]=1;
                            swap(box[i],box[cur_state]);
                        }
                        else col[i]=-1;
                    }
                }
                else if(piece[cur_piece]==2)
                {
                    for(int i=0;i<64;i++)
                    {
                        if(valid_ki(cur_state1,sq64to120[i],1)){
                            swap(box[i],box[cur_state]);
                            if(chk(sq64to120[i],1)==1)col[i]=1;
                            swap(box[i],box[cur_state]);
                        }
                        else col[i]=-1;
                    }
                }
                else if(piece[cur_piece]==3)
                {

                    for(int i=0;i<64;i++)
                    {
                        //cout<<"hu hu "<<cur_state1<<" "<<sq64to120[i]<<" "<<valid_pa(cur_state1,sq64to120[i],1)<<"\n";
                        if(valid_pa(cur_state1,sq64to120[i],1)){
                            swap(box[i],box[cur_state]);
                            if(chk(sq64to120[white_ki_pos],1)==1)col[i]=1;
                            swap(box[i],box[cur_state]);
                        }
                        else col[i]=-1;
                    }
                }
                else for(int i=0;i<64;i++)col[i]=-1;
            }
            else
            {
                if(piece[cur_piece]==7)
                {
                    for(int i=0;i<64;i++)
                    {
                        if(valid_knight(cur_state1,sq64to120[i],0)){
                            swap(box[i],box[cur_state]);
                            if(chk(sq64to120[black_ki_pos],0)==1)col[i]=1;
                            swap(box[i],box[cur_state]);
                        }
                        else col[i]=-1;
                    }
                }
                else if(piece[cur_piece]==06)
                {
                    for(int i=0;i<64;i++)
                    {
                        if(valid_b(cur_state1,sq64to120[i],0)){
                            swap(box[i],box[cur_state]);
                            if(chk(sq64to120[black_ki_pos],0)==1)col[i]=1;
                            swap(box[i],box[cur_state]);
                        }
                        else col[i]=-1;
                    }
                }
                else if(piece[cur_piece]==11)
                {
                    for(int i=0;i<64;i++)
                    {
                        if(valid_r(cur_state1,sq64to120[i],0)){
                            swap(box[i],box[cur_state]);
                            if(chk(sq64to120[black_ki_pos],0)==1)col[i]=1;
                            swap(box[i],box[cur_state]);
                        }
                        else col[i]=-1;
                    }
                }
                else if(piece[cur_piece]==10)
                {
                    for(int i=0;i<64;i++)
                    {
                        if(valid_qu(cur_state1,sq64to120[i],0)){
                            swap(box[i],box[cur_state]);
                            if(chk(sq64to120[black_ki_pos],0)==1)col[i]=1;
                            swap(box[i],box[cur_state]);
                        }
                        else col[i]=-1;
                    }
                }
                else if(piece[cur_piece]==8)
                {
                    for(int i=0;i<64;i++)
                    {
                        if(valid_ki(cur_state1,sq64to120[i],0)){
                            swap(box[i],box[cur_state]);
                            if(chk(sq64to120[i],0)==1)col[i]=1;
                            swap(box[i],box[cur_state]);
                        }
                        else col[i]=-1;
                    }
                }
                else if(piece[cur_piece]==9)
                {
                    for(int i=0;i<64;i++)
                    {
                        if(valid_pa(cur_state1,sq64to120[i],0)){
                            swap(box[i],box[cur_state]);
                            if(chk(sq64to120[black_ki_pos],0)==1)col[i]=1;
                            swap(box[i],box[cur_state]);
                        }
                        else col[i]=-1;
                    }
                }
                else for(int i=0;i<64;i++)col[i]=-1;
            }

            st=3;
        }
        else if(st==3 && button==GLUT_LEFT_BUTTON && state==GLUT_DOWN)
        {
            //cout<<mx<<" "<<my<<" "<<st<<" "<<cur_piece<<"\n";
            st=2;
            int cur_state=sq120to64[cur_state1];
            int cnt=sq120to64[stat(mx,my)],bx=sq120to64[cur_state1],cur_2=cur_state1;
            int undo=box[cnt];

            if(piece[cur_piece]==1)
            {
                if(valid_knight(cur_state1,stat(mx,my),1) && (total_move%2)==0)
                {
                    //cout<<"to "<<total_move<<"\n";
                    box[cnt]=cur_piece,total_move++;
                    if(chk(sq64to120[white_ki_pos],1)==0)box[cnt]=undo,box[bx]=cur_piece,total_move--;
                    else {
                        pus(1,bx,cnt),box[cur_state]=32;
                        white_ki_chk=0;
                        for(int i=0;i<64;i++)col[i]=-1;
                        if(chk(sq64to120[black_ki_pos],0)==0)black_ki_chk=1,moves.pb("Black in "),moves.pb("check!");
                        else black_ki_chk=0;
                    }
                    //cout<<"to "<<white_ki_chk<<" "<<black_ki_chk<<"\n";
                }
                else box[bx]=cur_piece;
            }
            else if( piece[cur_piece]==7)
            {
                if(valid_knight(cur_state1,stat(mx,my),0) && ((total_move%2)==1))
                {
                    box[cnt]=cur_piece,total_move++;
                    if(chk(sq64to120[black_ki_pos],0)==0)box[cnt]=undo,box[bx]=cur_piece,total_move--;
                    else {
                        for(int i=0;i<64;i++)col[i]=-1;
                        pus(7,bx,cnt),box[cur_state]=32;
                        black_ki_chk=0;
                        if(chk(sq64to120[white_ki_pos],1)==0)white_ki_chk=1,moves.pb("White in "),moves.pb("check!");
                        else white_ki_chk=0;
                    }
                }
                else box[bx]=cur_piece;

            }
            else if(piece[cur_piece]==0)
            {
                if(valid_b(cur_state1,stat(mx,my),1) &&  ((total_move%2)==0))
                {
                    box[cnt]=cur_piece,total_move++;
                    if(chk(sq64to120[white_ki_pos],1)==0)box[cnt]=undo,box[bx]=cur_piece,total_move--;
                    else {
                        for(int i=0;i<64;i++)col[i]=-1;
                        pus(0,bx,cnt),box[cur_state]=32;
                        white_ki_chk=0;
                        if(chk(sq64to120[black_ki_pos],0)==0)black_ki_chk=1,moves.pb("Black in "),moves.pb("check!");
                        else black_ki_chk=0;
                    }
                }
                else box[bx]=cur_piece;
            }
            else if(piece[cur_piece]==6)
            {
                if(valid_b(cur_state1,stat(mx,my),0) && (total_move%2)  )
                {
                    box[cnt]=cur_piece,total_move++;
                    if(chk(sq64to120[black_ki_pos],0)==0)box[cnt]=undo,box[bx]=cur_piece,total_move--;
                    else {
                        for(int i=0;i<64;i++)col[i]=-1;
                        pus(6,bx,cnt),box[cur_state]=32;
                        black_ki_chk=0;
                        if(chk(sq64to120[white_ki_pos],1)==0)white_ki_chk=1,moves.pb("White in "),moves.pb("check!");
                        else white_ki_chk=0;
                    }
                }
                else box[bx]=cur_piece;
            }
            else if(piece[cur_piece]==5 )
            {
                if(valid_r(cur_state1,stat(mx,my),1) && (total_move%2)==0  )
                {

                    box[cnt]=cur_piece,total_move++;
                    if(chk(sq64to120[white_ki_pos],1)==0)box[cnt]=undo,box[bx]=cur_piece,total_move--;
                    else{
                        pus(5,bx,cnt),box[cur_state]=32;
                        white_ki_chk=0;
                        for(int i=0;i<64;i++)col[i]=-1;
                        if(chk(sq64to120[black_ki_pos],0)==0)black_ki_chk=1,moves.pb("Black in"),moves.pb("check!");
                        else black_ki_chk=0;
                    }
                }
                else box[bx]=cur_piece;
            }
            else if(piece[cur_piece]==11)
            {
                if(valid_r(cur_state1,stat(mx,my),0) && (total_move%2)==1)
                {
                    box[cnt]=cur_piece,total_move++;
                    if(chk(sq64to120[black_ki_pos],0)==0)box[cnt]=undo,box[bx]=cur_piece,total_move--;
                    else{
                        pus(11,bx,cnt),box[cur_state]=32;
                        for(int i=0;i<64;i++)col[i]=-1;
                        black_ki_chk=0;
                        if(chk(sq64to120[white_ki_pos],1)==0)white_ki_chk=1,moves.pb("White in"),moves.pb("check!");
                        else white_ki_chk=0;
                    }
                }
                else box[bx]=cur_piece;
            }
            else if(piece[cur_piece]==4 )
            {
                if(valid_qu(cur_state1,stat(mx,my),1) && (total_move%2)==0 )
                {
                    box[cnt]=cur_piece,total_move++;
                    if(chk(sq64to120[white_ki_pos],1)==0)box[cnt]=undo,box[bx]=cur_piece,total_move--;
                    else{
                        for(int i=0;i<64;i++)col[i]=-1;
                        pus(4,bx,cnt),box[cur_state]=32;
                        white_ki_chk=0;
                        if(chk(sq64to120[black_ki_pos],0)==0)black_ki_chk=1,moves.pb("Black in "),moves.pb("check!");
                        else black_ki_chk=0;
                    }
                }
                else box[bx]=cur_piece;
            }
            else if(piece[cur_piece]==10)
            {
                if(valid_qu(cur_state1,stat(mx,my),0) && (total_move%2) )
                {
                    box[cnt]=cur_piece,total_move++;
                    if(chk(sq64to120[black_ki_pos],0)==0)box[cnt]=undo,box[bx]=cur_piece,total_move--;
                    else {
                        for(int i=0;i<64;i++)col[i]=-1;
                        pus(10,bx,cnt),box[cur_state]=32;
                        black_ki_chk=0;
                        if(chk(sq64to120[white_ki_pos],1)==0)white_ki_chk=1,moves.pb("White in"),moves.pb("check!");
                        else white_ki_chk=0;
                    }
                }
                else box[bx]=cur_piece;
            }
            else if(piece[cur_piece]==2)
            {
                //cout<<stat(mx,my)<<" "<<cur_state1<<" "<<cnt<<" "<<box[cnt]<<" "<<box[bx]<<"\n";
                if(valid_ki(cur_state1,stat(mx,my),1) && (total_move%2)==0 )
                {
                    if(chk(stat(mx,my),1)==01)
                    {

                        box[cnt]=cur_piece,total_move++,white_ki_pos=cnt;
                        if(chk(sq64to120[white_ki_pos],1)==0)white_ki_pos=cur_state1,total_move--,box[cnt]=undo,box[bx]=cur_piece;
                        else{
                            for(int i=0;i<64;i++)col[i]=-1;
                            pus(2,bx,cnt),box[cur_state]=32;
                            white_ki_chk=0;
                            if(chk(sq64to120[black_ki_pos],0)==0)black_ki_chk=1,moves.pb("Black in "),moves.pb("check!");
                            else black_ki_chk=0;
                        }
                    }
                    else box[bx]=cur_piece;
                }
                else box[bx]=cur_piece;
            }
            else if(piece[cur_piece]==8)
            {
                if(valid_ki(cur_state1,stat(mx,my),0) && (total_move%2) )
                {
                    if(chk(stat(mx,my),0)==01)
                    {
                        box[cnt]=cur_piece,total_move++,black_ki_pos=cnt;
                        if(chk(sq64to120[black_ki_pos],0)==0)black_ki_pos=cur_state1,box[cnt]=undo,box[bx]=cur_piece,total_move--,cout<<"vul\n";
                        else{
                            for(int i=0;i<64;i++)col[i]=-1;
                            pus(8,bx,cnt),box[cur_state]=32;
                            black_ki_chk=0;
                            if(chk(sq64to120[white_ki_pos],01)==0)white_ki_chk=1,moves.pb("White in "),moves.pb("check!");
                            else white_ki_chk=0;
                        }
                    }

                    else box[bx]=cur_piece;
                }
                else box[bx]=cur_piece;
            }
            else if(piece[cur_piece]==3)
            {
                if(valid_pa(cur_state1,stat(mx,my),1) && (total_move%2)==0 )
                {
                    box[cnt]=cur_piece,total_move++;
                    if(chk(sq64to120[white_ki_pos],1)==0)box[cnt]=undo,box[bx]=cur_piece,total_move--,cout<<chk(sq64to120[white_ki_pos],1)<<" chk\n";
                    else {
                        for(int i=0;i<64;i++)col[i]=-1;
                        pus(3,bx,cnt),box[cur_state]=32;
                        white_ki_chk=0,mov_piece[cur_piece]=1;
                        if(chk(sq64to120[black_ki_pos],0)==0)black_ki_chk=1,moves.pb("Black in "),moves.pb("check!");
                        else black_ki_chk=0;
                    }
                }
                else box[bx]=cur_piece;
            }
            else if(piece[cur_piece]==9)
            {
                if(valid_pa(cur_state1,stat(mx,my),0) && (total_move%2) )
                {
                    box[cnt]=cur_piece,total_move++;
                    if(chk(sq64to120[black_ki_pos],0)==0)box[cnt]=undo,box[bx]=cur_piece,total_move--;
                    else {
                        for(int i=0;i<64;i++)col[i]=-1;
                        pus(9,bx,cnt),box[cur_state]=32;
                        black_ki_chk=0,mov_piece[cur_piece]=1;
                        if(chk(sq64to120[white_ki_pos],1)==0)white_ki_chk=1,moves.pb("White in "),moves.pb("check!");
                        else white_ki_chk=0;
                    }
                }
                else box[bx]=cur_piece;
            }

            if(total_move%2==0)
            {
                if(white_ki_chk==1)
                {
                    int tot=0;
                    for(int i=0;tot==0 && i<=63;i++)
                    {
                        if(0<=box[i] && box[i]<=15)
                        {
                            for(int j=0;tot==0 && j<=63;j++)
                            {
                                if(!(0<=box[j] && box[j]<=15))
                                {
                                    int cnt=sq64to120[i],cnt2=sq64to120[j];
                                    if(piece[box[i]]==0)
                                    {
                                        if(valid_b(cnt,cnt2,1))
                                        {
                                            int undo=box[j],undo2=box[i];
                                            box[j]=box[i],box[i]=32;
                                            if(chk(sq64to120[white_ki_pos],1)==1)tot=1;
                                            box[j]=undo,box[i]=undo2;
                                        }
                                    }
                                    else if(piece[box[i]]==1)
                                    {
                                        if(valid_knight(cnt,cnt2,1)){
                                            int undo=box[j],undo2=box[i];
                                            box[j]=box[i],box[i]=32;
                                            if(chk(sq64to120[white_ki_pos],1)==1)tot=1;
                                            box[j]=undo,box[i]=undo2;
                                        }
                                    }
                                    else if(piece[box[i]]==2)
                                    {
                                        if(valid_ki(cnt,cnt2,1))
                                        {
                                            int undo=box[j],undo2=box[i];
                                            box[j]=box[i],box[i]=32;
                                            if(chk(cnt2,1)==1)tot=1;
                                            box[j]=undo,box[i]=undo2;
                                        }
                                    }
                                    else if(piece[box[i]]==3)
                                    {
                                        if(valid_pa(cnt,cnt2,1) )
                                        {
                                            int undo=box[j],undo2=box[i];
                                            box[j]=box[i],box[i]=32;
                                            if(chk(sq64to120[white_ki_pos],1)==1)tot=1;
                                            box[j]=undo,box[i]=undo2;
                                        }
                                    }
                                    else if(piece[box[i]]==4)
                                    {
                                        if(valid_qu(cnt,cnt2,1))
                                        {
                                            int undo=box[j],undo2=box[i];
                                            box[j]=box[i],box[i]=32;
                                            hmm=-1;
                                            if(chk(sq64to120[white_ki_pos],1)==1)tot=1;
                                            box[j]=undo,box[i]=undo2;
                                        }
                                    }
                                    else if(piece[box[i]]==5)
                                    {
                                        if(valid_r(cnt,cnt2,1))
                                        {
                                            int undo=box[j],undo2=box[i];
                                            box[j]=box[i],box[i]=32;
                                            hmm=-1;
                                            if(chk(sq64to120[white_ki_pos],1)==1)tot=1;
                                            box[j]=undo,box[i]=undo2;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if(tot==0){
                        exi=1;
                    }
                }
            }
            else{
                if(black_ki_chk==1)
                {
                    int tot=0;
                    for(int i=0;tot==0 && i<=63;i++)
                    {
                        if(box[i]>=16 && box[i]<=31 && box[i]!=32)
                        {
                            for(int j=0;tot==0 && j<=63;j++)
                            {
                                if((0<=box[j] && box[j]<=15) || box[j]==32)
                                {
                                    int cnt=sq64to120[i],cnt2=sq64to120[j];
                                    if(piece[box[i]]==6)
                                    {
                                        if(valid_b(cnt,cnt2,0))
                                        {
                                            int undo=box[j],undo2=box[i];
                                            box[j]=box[i],box[i]=32;
                                            if(chk(sq64to120[black_ki_pos],0)==1)tot=1,cout<<i<<" 0 "<<j<<"\n";
                                            box[j]=undo,box[i]=undo2;
                                        }
                                    }
                                    else if(piece[box[i]]==7)
                                    {
                                        if(valid_knight(cnt,cnt2,0)){
                                            int undo=box[j],undo2=box[i];
                                            box[j]=box[i],box[i]=32;
                                            if(chk(sq64to120[black_ki_pos],0)==1)tot=1,cout<<i<<" 1 "<<j<<"\n";
                                            box[j]=undo,box[i]=undo2;
                                        }
                                    }
                                    else if(piece[box[i]]==8)
                                    {
                                        if(valid_ki(cnt,cnt2,0))
                                        {

                                            //cout<<"hmm "<<hmm<<" "<<chk(cnt2,0)<<"\n";
                                            int undo=box[j],undo2=box[i];
                                            box[j]=box[i],box[i]=32;
                                            if(chk(cnt2,0)==1)tot=1;
                                            box[j]=undo,box[i]=undo2;
                                        }
                                    }
                                    else if(piece[box[i]]==9)
                                    {
                                        if(valid_pa(cnt,cnt2,0) )
                                        {
                                            int undo=box[j],undo2=box[i];
                                            box[j]=box[i],box[i]=32;
                                            if(chk(sq64to120[black_ki_pos],0)==1)tot=1;
                                            box[j]=undo,box[i]=undo2;
                                        }
                                    }
                                    else if(piece[box[i]]==10)
                                    {
                                        if(valid_qu(cnt,cnt2,0))
                                        {
                                            int undo=box[j],undo2=box[i];
                                            box[j]=box[i],box[i]=32;
                                            if(chk(sq64to120[black_ki_pos],0)==1)tot=1;
                                            box[j]=undo,box[i]=undo2;
                                        }
                                    }
                                    else if(piece[box[i]]==11)
                                    {
                                        if(valid_r(cnt,cnt2,0))
                                        {
                                            int undo=box[j],undo2=box[i];
                                            box[j]=box[cnt],box[i]=32;
                                            if(chk(sq64to120[black_ki_pos],0)==1)tot=1;
                                            box[j]=undo,box[i]=undo2;
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if(tot==0){
                        exi=2;
                    }
                }
            }
            if(exi!=1 && exi!=2)
            {

                for(int i=0;i<8;i++)
                {
                    if(piece[box[i]]==9)
                    {
                        box[i]=27;
                    }
                }
                for(int i=0;i<8;i++)
                {
                    if(piece[box[63-i]]==3)box[63-i]=3;
                }
            }
        }
	}
}
void iPassiveMouseMove(int mx, int my)
{

}

/*
	function iKeyboard() is called whenever the user hits a key in keyboard.
	key- holds the ASCII value of the key pressed.
*/
void iKeyboard(unsigned char key)
{
	int i;
	if(st==-2)
	{
        if(key == '\r')
		{
			mode = 0;
			strcpy(str2, str);
			printf("%s\n", str2);
			for(i = 0; i < len; i++)
				str[i] = 0;
			len = 0;
		}
		else
		{
			str[len] = key;
			len++;
		}
	}

	if(key == 'x')
	{
		//do something with 'x'
		exit(0);
	}
	//place your codes for other keys here
}

/*
	function iSpecialKeyboard() is called whenver user hits special keys like-
	function keys, home, end, pg up, pg down, arraows etc. you have to use
	appropriate constants to detect them. A list is:
	GLUT_KEY_F1, GLUT_KEY_F2, GLUT_KEY_F3, GLUT_KEY_F4, GLUT_KEY_F5, GLUT_KEY_F6,
	GLUT_KEY_F7, GLUT_KEY_F8, GLUT_KEY_F9, GLUT_KEY_F10, GLUT_KEY_F11, GLUT_KEY_F12,
	GLUT_KEY_LEFT, GLUT_KEY_UP, GLUT_KEY_RIGHT, GLUT_KEY_DOWN, GLUT_KEY_PAGE UP,
	GLUT_KEY_PAGE DOWN, GLUT_KEY_HOME, GLUT_KEY_END, GLUT_KEY_INSERT
*/
void iSpecialKeyboard(unsigned char key)
{

	if(key == GLUT_KEY_UP)
	{
		y+=64*2;
	}

	//place your codes for other keys here
}
void piece_number()
{
    for(int i=0;i<16;i++)piece[i]=21+i;
    for(int i=0;i<16;i++)piece[i+16]=81+i;
}
int main()
{
	//place your own initialization codes here.
	white_ki_pos=4,black_ki_pos=60;
	piece_number();
	initsq120to64();
	pieceknight[1]=pieceknight[7]=1,pieceki[2]=pieceki[8]=1;
    piecerqu[4]=piecerqu[5]=piecerqu[10]=piecerqu[11]=11;
    piecebq[0]=piecebq[6]=piecebq[4]=piecebq[10]=1;
	for(int i=0;i<=63;i++)box[i]=32,col[i]=-1;
	for(int i=0;i<16;i++)box[i]=i;
	for(int i=48,j=16;i<=63;i++,j++)box[i]=j;
	for(int ind=0;ind<64;ind++)
	{
	    int p=sq64to120[ind];
	    int x2=x1+((ind)%8)*64,y2=(y1+(7-(ind)/8)*64);
	    stat_to_co[p].x_co=x2,
	    stat_to_co[p].y_co=y2;
	    //cout<<p<<" "<<x2<<" "<<y2<<"\n";
	}
	//PlaySound("bgm.wav", NULL, SND_LOOP|SND_ASYNC);
	piece[0]=piece[7]=5,piece[1]=piece[6]=1,piece[2]=piece[5]=0,piece[3]=4,piece[4]=2;
	for(int i=8;i<16;i++)piece[i]=3;
	for(int i=16;i<24;i++)piece[i]=9;
	piece[24]=piece[31]=11,piece[25]=piece[30]=7,piece[26]=piece[29]=6,piece[27]=10,piece[28]=8;
	initsq120to64();
	len = 0;
	mode = 0;
	str[0]= 0;
	iInitialize(700,700, "ChessBotCom");
	return 0;
}

